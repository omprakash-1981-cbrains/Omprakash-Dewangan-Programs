﻿namespace CarPoolingWebApi.Models.Client
{
    public class Point
    {
        public string City { get; set; }

        public string Longitude { get; set; }

        public string Latitude { get; set; }
    }
}
