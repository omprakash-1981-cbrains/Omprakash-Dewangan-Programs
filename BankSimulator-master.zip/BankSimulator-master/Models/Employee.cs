﻿
namespace BankSimulator.Models
{
    public class Employee : User
    {
        public string Id { get; set; }

        public string BranchId { get; set; }
    }
}
