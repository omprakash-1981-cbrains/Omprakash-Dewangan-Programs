import * as React from "react";
import { Navbar} from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Navigation extends React.Component {
  render() {
    return (
      <nav className="navbar navbar-dark bg-primary">
          Address Book
      </nav>
    );
  }
}
